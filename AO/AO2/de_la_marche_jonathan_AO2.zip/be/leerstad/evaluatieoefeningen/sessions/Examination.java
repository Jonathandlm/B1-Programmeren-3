package be.leerstad.evaluatieoefeningen.sessions;

public class Examination {

    private double result;

    public Examination(double result) {
        this.result = result;
    }

    public double getResult() {
        return result;
    }

}
