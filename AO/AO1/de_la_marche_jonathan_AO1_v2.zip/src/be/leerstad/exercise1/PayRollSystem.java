package be.leerstad.exercise1;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

class PayRollSystem {

    private List<Employee> employeeList = new ArrayList<>();

    void addEmployee(Employee employee){
        employeeList.add(employee);
    }

    /*
    public void removeEmployee(Employee employee){
        employeeList.remove(employee);
    }
    */

    void printEmployeeEarnings(){
        for (Employee employee : employeeList) {
            System.out.format(Locale.US, "%s\n", employee);
            System.out.format(Locale.US, "earned: €%,.2f\n\n", employee.earnings());
        }
    }

    void printEmployeeTypes(){
        for (int employeeIndex = 0; employeeIndex < employeeList.size(); employeeIndex++) {
            System.out.format("Employee %d is a %s\n",
                    employeeIndex, employeeList.get(employeeIndex).getClass().getCanonicalName());
        }
    }

    void setPayRollBonus(double payRollBonus){
        Employee.setBonus(payRollBonus);
    }
}