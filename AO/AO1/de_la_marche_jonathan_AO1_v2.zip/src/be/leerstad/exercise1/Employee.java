package be.leerstad.exercise1;

import java.util.Locale;

abstract class Employee {
    private String firstName;
    private String lastName;
    private String socialSecurityNumber;
    private static double bonus = 0;

    Employee(String firstName, String lastName, String socialSecurityNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
    }

    private String getFirstName() { return firstName; }
    private String getLastName() { return lastName; }
    private String getSocialSecurityNumber() { return socialSecurityNumber; }
    static double getBonus() { return bonus; }

    static void setBonus(double bonus) { Employee.bonus = bonus; }

    @Override
    public String toString() {
        return String.format(Locale.US, "%s %s\nsocial security number: %s",
                getFirstName(), getLastName(), getSocialSecurityNumber());
    }

    public abstract double earnings();
}
