import be.leerstad.exercise1.*;

public class Main {

    public static void main(String[] args) {
        PayRollSystem payRollSystem = new PayRollSystem();
        Employee.setBonus(0.10);

        Employee peter = new SalariedEmployee("Peter", "Hardeel", "111-11-1111", 800);
        Employee johan = new HourlyEmployee("Johan", "Van Roste", "222-22-2222", 16.75, 40);
        Employee sacha = new CommissionEmployee("Sacha", "Demaere", "333-33-3333", 10000, 0.06);
        Employee manuela = new BasePlusCommissionEmployee("Manuela", "Deplucker", "444-44-4444", 5000, 0.04, 300);

        payRollSystem.addEmployee(peter);
        payRollSystem.addEmployee(johan);
        payRollSystem.addEmployee(sacha);
        payRollSystem.addEmployee(manuela);

        // TEST
        System.out.printf("%s :\n\n", payRollSystem.getClass().getSimpleName());
        payRollSystem.printEmployeeEarnings();
        payRollSystem.printEmployeeTypes();
    }
}
