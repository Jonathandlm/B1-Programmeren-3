package be.leerstad.exercise1;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PayRollSystem {
    private int numberEmployees;

    public PayRollSystem() {
        this.numberEmployees = 0;
    }

    private List<Employee> employeeList = new ArrayList<>();

    public void addEmployee(Employee employee){
        employeeList.add(employee);
        numberEmployees++;
    }

    /*
    public void removeEmployee(Employee employee){
        employeeList.remove(employee);
        numberEmployees--;
    }

    public int getNumberEmployees() {
        return numberEmployees;
    }
    */

    public void printEmployeeEarnings(){
        for (Employee employee : employeeList) {
            System.out.format(Locale.US, "%s\n", employee);
            System.out.format(Locale.US, "earned: €%,.2f\n\n", employee.earnings());
        }
    }

    public void printEmployeeTypes(){
        for (int employeeIndex = 0; employeeIndex < numberEmployees; employeeIndex++) {
            System.out.format("Employee %d is a %s\n",
                    employeeIndex, employeeList.get(employeeIndex).getClass().getCanonicalName());
        }
    }
}