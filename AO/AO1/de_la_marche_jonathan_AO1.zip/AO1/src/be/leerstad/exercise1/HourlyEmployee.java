package be.leerstad.exercise1;

import java.util.Locale;

public class HourlyEmployee extends Employee {
    private double hourlyWage;
    private double hoursWorked;

    public HourlyEmployee(String firstName, String lastName, String socialSecurityNumber,
                          double hourlyWage, double hoursWorked) {
        super(firstName, lastName, socialSecurityNumber);
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    private double getHourlyWage() { return hourlyWage; }
    private double getHoursWorked() { return hoursWorked; }

    public double earnings() {
        return calculateEarnings(getHourlyWage(), getHoursWorked());
    }

    private double calculateEarnings(double hourlyWage, double hoursWorked) {
        double overtime = 40;
        return hourlyWage * hoursWorked +
                ((hoursWorked > overtime) ? (hoursWorked - overtime) * hourlyWage * Employee.getBonus() : 0);
    }

    public String toString(){
        return String.format(Locale.US, "hourly employee: %s\n" +
                        "hourly wage: €%,.2f; hours worked: %,.2f",
                super.toString(), getHourlyWage(), getHoursWorked());
    }
}
