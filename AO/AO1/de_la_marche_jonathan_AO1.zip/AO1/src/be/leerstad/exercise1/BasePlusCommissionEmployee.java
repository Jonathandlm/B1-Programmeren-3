package be.leerstad.exercise1;

import java.util.Locale;

public class BasePlusCommissionEmployee extends CommissionEmployee {
    private double baseSalary;

    public BasePlusCommissionEmployee(String firstName, String lastName, String socialSecurityNumber,
                                      double grossSales, double commissionRate, double baseSalary) {
        super(firstName, lastName, socialSecurityNumber, grossSales, commissionRate);
        this.baseSalary = baseSalary;
    }

    private double getBaseSalary() { return baseSalary; }

    public double earnings() {
        return calculateEarnings(getGrossSales(), getCommissionRate(), getBaseSalary());
    }

    private double calculateEarnings(double grossSales, double commissionRate, double baseSalary) {
        return grossSales * commissionRate + baseSalary;
    }

    public String toString(){
        return String.format(Locale.US, "base-salaried %s; base salary: €%,.2f",
                super.toString(), getBaseSalary());
    }
}
