package be.leerstad.exercise1;

import java.util.Locale;

public class CommissionEmployee extends Employee {
    private double grossSales;
    private double commissionRate;

    public CommissionEmployee(String firstName, String lastName, String socialSecurityNumber,
                              double grossSales, double commissionRate) {
        super(firstName, lastName, socialSecurityNumber);
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }

    double getGrossSales() { return grossSales; }
    double getCommissionRate() { return commissionRate; }

    public double earnings() {
        return calculateEarnings(getGrossSales(), getCommissionRate());
    }

    private double calculateEarnings(double grossSales, double commissionRate) {
        return grossSales * commissionRate;
    }

    public String toString(){
        return String.format(Locale.US, "commission employee: %s\n" +
                        "gross sales: €%,.2f; commission rate: %,.2f",
                super.toString(), getGrossSales(), getCommissionRate());
    }
}