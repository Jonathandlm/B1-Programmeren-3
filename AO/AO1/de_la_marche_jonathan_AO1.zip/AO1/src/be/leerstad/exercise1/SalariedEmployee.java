package be.leerstad.exercise1;

import java.util.Locale;

public class SalariedEmployee extends Employee {
    private double weeklySalary;

    public SalariedEmployee(String firstName, String lastName, String socialSecurityNumber, double weeklySalary) {
        super(firstName, lastName, socialSecurityNumber);
        this.weeklySalary = weeklySalary;
    }

    private double getWeeklySalary() { return weeklySalary; }

    public double earnings() {
        return calculateEarnings(getWeeklySalary());
    }

    private double calculateEarnings(double weeklySalary) {
        return weeklySalary;
    }

    public String toString(){
        return String.format(Locale.US, "salaried employee: %s\n" +
                "weekly salary: €%,.2f",
                super.toString(), getWeeklySalary());
    }
}
